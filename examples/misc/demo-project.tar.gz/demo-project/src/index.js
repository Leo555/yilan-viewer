export const hello = (name) => `你好，${name}`;
